jQuery(document).ready(function($) {
    $('.variations_form').each(function() {
        $(this).wc_variation_form();
    });

    $(document).on('submit', '.variations_form', function(e) {
        e.preventDefault();
        let $form = $(this);
        let data = $form.serialize();

        $.ajax({
            type: 'POST',
            url: ajax_var_add.ajax_url,
            data: data + '&action=variation_add_to_cart', // ✅ Sends top-level POST vars
            success: function(response) {
                $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $form]);
            },
            error: function(err) {
                console.log(err);
            }
        });
    });
});
