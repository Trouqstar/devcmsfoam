<?php
/**
 * Template Name: Vinyl and Linings Template
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="sundries-outer-wrapper">
        <?php get_template_part('product-content/vinyl-and-linings'); ?>
    </div>
</main>

<?php get_footer(); ?>
