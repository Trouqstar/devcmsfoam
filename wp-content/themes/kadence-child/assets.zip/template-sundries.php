<?php
/**
 * Template Name: Sundries Page
 */
get_header(); ?>

<!-- Only this wrapper added -->
<div class="sundries-outer-wrapper">
    <?php include_once(get_stylesheet_directory() . '/sundries-content.php'); ?>
</div>

<?php get_footer(); ?>