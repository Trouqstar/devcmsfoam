<?php
/**
 * Plugin Name: AJAX Variation Add to Cart
 * Description: Enables adding variable products via AJAX from shop/wishlist pages.
 * Version: 1.0
 * Author: You
 */

defined('ABSPATH') || exit;

add_action('wp_enqueue_scripts', function () {
    if (is_shop() || is_product_category() || is_product_tag() || is_page('wishlist')) {
        wp_enqueue_script('wc-add-to-cart-variation');
        wp_enqueue_script('variation-add-js', plugin_dir_url(__FILE__) . 'assets/js/variation-add.js', ['jquery'], null, true);
        wp_localize_script('variation-add-js', 'ajax_var_add', [
            'ajax_url' => admin_url('admin-ajax.php')
        ]);
    }
});

add_action('wp_ajax_variation_add_to_cart', 'custom_ajax_add_to_cart_variable');
add_action('wp_ajax_nopriv_variation_add_to_cart', 'custom_ajax_add_to_cart_variable');

function custom_ajax_add_to_cart_variable() {
    parse_str($_POST['data'], $post_data);

    wc()->frontend_includes();
    $_POST = array_merge($_POST, $post_data);

    WC_Form_Handler::add_to_cart_action();

    if (wc_notice_count('error') === 0) {
        WC_AJAX::get_refreshed_fragments();
    } else {
        wc_print_notices();
    }

    wp_die();
}
