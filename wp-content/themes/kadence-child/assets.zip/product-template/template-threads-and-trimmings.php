<?php
/**
 * Template Name: Threads and Trimmings Template
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="sundries-outer-wrapper">
        <?php get_template_part('product-content/threads-and-trimmings'); ?>
    </div>
</main>

<?php get_footer(); ?>
